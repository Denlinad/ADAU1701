EESchema Schematic File Version 4
LIBS:RDC2-0027v3-cache
EELAYER 29 0
EELAYER END
$Descr A3 16535 11693
encoding utf-8
Sheet 1 1
Title ""
Date ""
Rev ""
Comp ""
Comment1 ""
Comment2 ""
Comment3 ""
Comment4 ""
$EndDescr
$Comp
L RDC2-0027v3-rescue:ADAU1701-RDC2-0027v2-rescue DD2
U 1 1 59A529BA
P 7800 4950
F 0 "DD2" H 7750 6200 60  0000 C CNN
F 1 "ADAU1701" H 7750 3650 60  0000 C CNN
F 2 "Housings_QFP:LQFP-48_7x7mm_Pitch0.5mm" H 7800 4950 60  0001 C CNN
F 3 "" H 7800 4950 60  0000 C CNN
	1    7800 4950
	1    0    0    -1  
$EndComp
Text GLabel 6400 4800 0    60   Input ~ 0
MP0
Text GLabel 6400 4700 0    60   Input ~ 0
MP1
Text GLabel 6400 4600 0    60   Input ~ 0
MP5
Text GLabel 6400 4500 0    60   Input ~ 0
MP4
Text GLabel 6400 5100 0    60   Input ~ 0
MP7
Text GLabel 6400 5200 0    60   Input ~ 0
MP6
Text GLabel 6400 5300 0    60   Input ~ 0
MP10
Text GLabel 6400 5600 0    60   Input ~ 0
MP11
Text GLabel 8875 6000 2    60   Input ~ 0
MP9
Text GLabel 8875 5900 2    60   Input ~ 0
MP8
Text GLabel 12575 8375 0    60   Input ~ 0
MP0
Text GLabel 2450 6225 2    60   Input ~ 0
MP1
Text GLabel 2450 6325 2    60   Input ~ 0
MP2
Text GLabel 2450 6425 2    60   Input ~ 0
MP3
Text GLabel 12575 8175 0    60   Input ~ 0
MP4
Text GLabel 12575 8275 0    60   Input ~ 0
MP5
Text GLabel 2450 7025 2    60   Input ~ 0
MP6
Text GLabel 2450 6625 2    60   Input ~ 0
MP7
Text GLabel 2450 6725 2    60   Input ~ 0
MP8
Text GLabel 2450 6525 2    60   Input ~ 0
MP9
Text GLabel 6400 4900 0    60   Input ~ 0
GND
Text GLabel 8875 6100 2    60   Input ~ 0
GND
$Comp
L Device:CP_Small C10
U 1 1 59A573AB
P 5050 5650
F 0 "C10" H 5060 5720 50  0000 L CNN
F 1 "10мкФ" H 5060 5570 50  0000 L CNN
F 2 "Capacitors_Tantalum_SMD:TantalC_SizeA_EIA-3216_Reflow" H 5050 5650 50  0001 C CNN
F 3 "" H 5050 5650 50  0000 C CNN
	1    5050 5650
	1    0    0    -1  
$EndComp
Text GLabel 4850 5800 0    60   Input ~ 0
GND
Text GLabel 4850 5500 0    60   Input ~ 0
3V3
$Comp
L Device:CP_Small C33
U 1 1 59A5924E
P 11200 5350
F 0 "C33" H 11210 5420 50  0000 L CNN
F 1 "10мкФ" H 11210 5270 50  0000 L CNN
F 2 "Capacitors_Tantalum_SMD:CP_Tantalum_Case-A_EIA-3216-18_Reflow" H 11200 5350 50  0001 C CNN
F 3 "" H 11200 5350 50  0000 C CNN
	1    11200 5350
	1    0    0    -1  
$EndComp
$Comp
L Device:C_Small C31
U 1 1 59A59254
P 10850 5350
F 0 "C31" H 10860 5420 50  0000 L CNN
F 1 "0,1мкФ" H 10860 5270 50  0000 L CNN
F 2 "Capacitors_SMD:C_0603_HandSoldering" H 10850 5350 50  0001 C CNN
F 3 "" H 10850 5350 50  0000 C CNN
	1    10850 5350
	1    0    0    -1  
$EndComp
Text GLabel 11550 5500 2    60   Input ~ 0
GND
Text GLabel 11550 5200 2    60   Input ~ 0
3V3
$Comp
L Device:R R6
U 1 1 59A5A319
P 5600 4000
F 0 "R6" V 5525 3950 50  0000 C CNN
F 1 "18k2" V 5600 4000 50  0000 C CNN
F 2 "Resistors_SMD:R_0603_HandSoldering" V 5530 4000 50  0001 C CNN
F 3 "" H 5600 4000 50  0000 C CNN
	1    5600 4000
	0    1    1    0   
$EndComp
Text GLabel 5300 4000 0    60   Input ~ 0
GND
$Comp
L Device:C_Small C30
U 1 1 59A5B873
P 10500 5350
F 0 "C30" H 10510 5420 50  0000 L CNN
F 1 "0,1мкФ" H 10510 5270 50  0000 L CNN
F 2 "Capacitors_SMD:C_0603_HandSoldering" H 10500 5350 50  0001 C CNN
F 3 "" H 10500 5350 50  0000 C CNN
	1    10500 5350
	1    0    0    -1  
$EndComp
$Comp
L Device:C_Small C27
U 1 1 59A5B8C5
P 10150 5350
F 0 "C27" H 10160 5420 50  0000 L CNN
F 1 "0,1мкФ" H 10160 5270 50  0000 L CNN
F 2 "Capacitors_SMD:C_0603_HandSoldering" H 10150 5350 50  0001 C CNN
F 3 "" H 10150 5350 50  0000 C CNN
	1    10150 5350
	1    0    0    -1  
$EndComp
$Comp
L Device:C_Small C12
U 1 1 59A5BBCD
P 5400 5650
F 0 "C12" H 5410 5720 50  0000 L CNN
F 1 "0,1мкФ" H 5410 5570 50  0000 L CNN
F 2 "Capacitors_SMD:C_0603_HandSoldering" H 5400 5650 50  0001 C CNN
F 3 "" H 5400 5650 50  0000 C CNN
	1    5400 5650
	1    0    0    -1  
$EndComp
$Comp
L Device:C_Small C26
U 1 1 59A5BF7A
P 10150 4750
F 0 "C26" H 10160 4820 50  0000 L CNN
F 1 "0,1мкФ" H 10160 4670 50  0000 L CNN
F 2 "Capacitors_SMD:C_0603_HandSoldering" H 10150 4750 50  0001 C CNN
F 3 "" H 10150 4750 50  0000 C CNN
	1    10150 4750
	1    0    0    -1  
$EndComp
$Comp
L Device:C_Small C25
U 1 1 59A5C162
P 10150 4050
F 0 "C25" H 10160 4120 50  0000 L CNN
F 1 "0,1мкФ" H 10160 3970 50  0000 L CNN
F 2 "Capacitors_SMD:C_0603_HandSoldering" H 10150 4050 50  0001 C CNN
F 3 "" H 10150 4050 50  0000 C CNN
	1    10150 4050
	1    0    0    -1  
$EndComp
$Comp
L Device:C_Small C29
U 1 1 59A5C1D3
P 10500 4750
F 0 "C29" H 10510 4820 50  0000 L CNN
F 1 "10мкФ" H 10510 4670 50  0000 L CNN
F 2 "Capacitors_SMD:C_0805_HandSoldering" H 10500 4750 50  0001 C CNN
F 3 "" H 10500 4750 50  0000 C CNN
	1    10500 4750
	1    0    0    -1  
$EndComp
$Comp
L Device:C_Small C28
U 1 1 59A5C85C
P 10500 4050
F 0 "C28" H 10510 4120 50  0000 L CNN
F 1 "10мкФ" H 10510 3970 50  0000 L CNN
F 2 "Capacitors_SMD:C_0805_HandSoldering" H 10500 4050 50  0001 C CNN
F 3 "" H 10500 4050 50  0000 C CNN
	1    10500 4050
	1    0    0    -1  
$EndComp
Text GLabel 10800 4200 2    60   Input ~ 0
GND
$Comp
L Device:C_Small C32
U 1 1 59A5DB40
P 10900 4750
F 0 "C32" H 10910 4820 50  0000 L CNN
F 1 "0,1мкФ" H 10910 4670 50  0000 L CNN
F 2 "Capacitors_SMD:C_0603_HandSoldering" H 10900 4750 50  0001 C CNN
F 3 "" H 10900 4750 50  0000 C CNN
	1    10900 4750
	1    0    0    -1  
$EndComp
$Comp
L Device:C_Small C34
U 1 1 59A5DB46
P 11250 4750
F 0 "C34" H 11260 4820 50  0000 L CNN
F 1 "10мкФ" H 11260 4670 50  0000 L CNN
F 2 "Capacitors_SMD:C_0805_HandSoldering" H 11250 4750 50  0001 C CNN
F 3 "" H 11250 4750 50  0000 C CNN
	1    11250 4750
	1    0    0    -1  
$EndComp
Text GLabel 11550 4900 2    60   Input ~ 0
GND
$Comp
L Device:R R18
U 1 1 59A5EA6D
P 12550 5500
F 0 "R18" V 12650 5450 50  0000 C CNN
F 1 "475R" V 12550 5500 50  0000 C CNN
F 2 "Resistors_SMD:R_0603_HandSoldering" V 12480 5500 50  0001 C CNN
F 3 "" H 12550 5500 50  0000 C CNN
	1    12550 5500
	0    1    1    0   
$EndComp
$Comp
L Device:C_Small C35
U 1 1 59A5EB41
P 12200 5500
F 0 "C35" V 12300 5500 50  0000 L CNN
F 1 "56нФ" V 12100 5400 50  0000 L CNN
F 2 "Capacitors_SMD:C_0603_HandSoldering" H 12200 5500 50  0001 C CNN
F 3 "" H 12200 5500 50  0000 C CNN
	1    12200 5500
	0    -1   -1   0   
$EndComp
$Comp
L Device:C_Small C36
U 1 1 59A5EC0D
P 12350 5300
F 0 "C36" V 12450 5150 50  0000 L CNN
F 1 "3,3нФ" V 12300 5000 50  0000 L CNN
F 2 "Capacitors_SMD:C_0603_HandSoldering" H 12350 5300 50  0001 C CNN
F 3 "" H 12350 5300 50  0000 C CNN
	1    12350 5300
	0    -1   -1   0   
$EndComp
Text GLabel 12900 5500 2    60   Input ~ 0
3V3
$Comp
L Device:CP_Small C8
U 1 1 59A606F8
P 4700 5150
F 0 "C8" H 4710 5220 50  0000 L CNN
F 1 "10мкФ" H 4710 5070 50  0000 L CNN
F 2 "Capacitors_Tantalum_SMD:TantalC_SizeA_EIA-3216_Reflow" H 4700 5150 50  0001 C CNN
F 3 "" H 4700 5150 50  0000 C CNN
	1    4700 5150
	1    0    0    -1  
$EndComp
$Comp
L Device:C_Small C9
U 1 1 59A6077D
P 5050 5150
F 0 "C9" H 5060 5220 50  0000 L CNN
F 1 "0,1мкФ" H 5060 5070 50  0000 L CNN
F 2 "Capacitors_SMD:C_0603_HandSoldering" H 5050 5150 50  0001 C CNN
F 3 "" H 5050 5150 50  0000 C CNN
	1    5050 5150
	1    0    0    -1  
$EndComp
$Comp
L Device:C_Small C11
U 1 1 59A608C2
P 5400 5150
F 0 "C11" H 5410 5220 50  0000 L CNN
F 1 "0,1мкФ" H 5410 5070 50  0000 L CNN
F 2 "Capacitors_SMD:C_0603_HandSoldering" H 5400 5150 50  0001 C CNN
F 3 "" H 5400 5150 50  0000 C CNN
	1    5400 5150
	1    0    0    -1  
$EndComp
Text GLabel 4550 5300 0    60   Input ~ 0
GND
$Comp
L Device:Q_PNP_BEC VT1
U 1 1 59A614AD
P 3800 5400
F 0 "VT1" H 4100 5450 50  0000 R CNN
F 1 "FMMT717TA" H 4400 5350 50  0000 R CNN
F 2 "RDC2-0027:SOT-23" H 4000 5500 50  0001 C CNN
F 3 "" H 3800 5400 50  0000 C CNN
	1    3800 5400
	-1   0    0    -1  
$EndComp
$Comp
L Device:R R3
U 1 1 59A6275C
P 4100 5650
F 0 "R3" V 4025 5600 50  0000 C CNN
F 1 "1k" V 4100 5650 50  0000 C CNN
F 2 "Resistors_SMD:R_0603_HandSoldering" V 4030 5650 50  0001 C CNN
F 3 "" H 4100 5650 50  0000 C CNN
	1    4100 5650
	1    0    0    1   
$EndComp
Text GLabel 3550 5900 0    60   Input ~ 0
3V3
$Comp
L Device:C_Small C6
U 1 1 59A669BA
P 4250 3400
F 0 "C6" V 4350 3400 50  0000 L CNN
F 1 "10мкФ" V 4150 3300 50  0000 L CNN
F 2 "Capacitors_SMD:C_0805_HandSoldering" H 4250 3400 50  0001 C CNN
F 3 "" H 4250 3400 50  0000 C CNN
	1    4250 3400
	0    -1   -1   0   
$EndComp
$Comp
L Device:C_Small C3
U 1 1 59A67BD3
P 3800 3600
F 0 "C3" H 3810 3670 50  0000 L CNN
F 1 "100пФ" H 3810 3520 50  0000 L CNN
F 2 "Capacitors_SMD:C_0603_HandSoldering" H 3800 3600 50  0001 C CNN
F 3 "" H 3800 3600 50  0000 C CNN
	1    3800 3600
	1    0    0    -1  
$EndComp
Text GLabel 3950 3800 2    60   Input ~ 0
GND
$Comp
L Device:C_Small C7
U 1 1 59A6B6D3
P 4250 4100
F 0 "C7" V 4350 4100 50  0000 L CNN
F 1 "10мкФ" V 4150 4000 50  0000 L CNN
F 2 "Capacitors_SMD:C_0805_HandSoldering" H 4250 4100 50  0001 C CNN
F 3 "" H 4250 4100 50  0000 C CNN
	1    4250 4100
	0    -1   -1   0   
$EndComp
$Comp
L Device:C_Small C4
U 1 1 59A6B6DF
P 3800 4300
F 0 "C4" H 3810 4370 50  0000 L CNN
F 1 "100пФ" H 3810 4220 50  0000 L CNN
F 2 "Capacitors_SMD:C_0603_HandSoldering" H 3800 4300 50  0001 C CNN
F 3 "" H 3800 4300 50  0000 C CNN
	1    3800 4300
	1    0    0    -1  
$EndComp
Text GLabel 3950 4500 2    60   Input ~ 0
GND
Text GLabel 11600 2600 0    60   Input ~ 0
GND
$Comp
L Device:R R1
U 1 1 59A86DB8
P 3600 3600
F 0 "R1" V 3700 3650 50  0000 C CNN
F 1 "49k9" V 3600 3600 50  0000 C CNN
F 2 "Resistors_SMD:R_0603_HandSoldering" V 3530 3600 50  0001 C CNN
F 3 "" H 3600 3600 50  0000 C CNN
	1    3600 3600
	1    0    0    -1  
$EndComp
$Comp
L Device:R R2
U 1 1 59A87AD4
P 3600 4300
F 0 "R2" V 3700 4350 50  0000 C CNN
F 1 "49k9" V 3600 4300 50  0000 C CNN
F 2 "Resistors_SMD:R_0603_HandSoldering" V 3530 4300 50  0001 C CNN
F 3 "" H 3600 4300 50  0000 C CNN
	1    3600 4300
	1    0    0    -1  
$EndComp
$Comp
L Device:C_Small C15
U 1 1 59A5DAF9
P 9625 8725
F 0 "C15" H 9635 8795 50  0000 L CNN
F 1 "22пФ" H 9635 8645 50  0000 L CNN
F 2 "Capacitors_SMD:C_0603_HandSoldering" H 9625 8725 50  0001 C CNN
F 3 "" H 9625 8725 50  0000 C CNN
	1    9625 8725
	1    0    0    -1  
$EndComp
$Comp
L Device:C_Small C20
U 1 1 59A5DD60
P 10025 8725
F 0 "C20" H 10035 8795 50  0000 L CNN
F 1 "22пФ" H 10035 8645 50  0000 L CNN
F 2 "Capacitors_SMD:C_0603_HandSoldering" H 10025 8725 50  0001 C CNN
F 3 "" H 10025 8725 50  0000 C CNN
	1    10025 8725
	1    0    0    -1  
$EndComp
Text GLabel 6400 5700 0    60   Input ~ 0
CDATA/WB
Text GLabel 6400 5800 0    60   Input ~ 0
CLATCH/WP
Text GLabel 6400 5900 0    60   Input ~ 0
SDA/COUT
Text GLabel 6400 6000 0    60   Input ~ 0
SCL/CCLK
$Comp
L RDC2-0027v3-rescue:24C16-RDC2-0027v2-rescue DD1
U 1 1 59A7E41F
P 7500 7150
F 0 "DD1" H 7650 7500 50  0000 C CNN
F 1 "I2C_EEPROM_SOIC" H 7900 6750 50  0000 C CNN
F 2 "RDC2-0027:SOIC-8_3.9x4.9mm_Pitch1.27mm" H 7500 7150 50  0001 C CNN
F 3 "" H 7500 7150 50  0000 C CNN
	1    7500 7150
	1    0    0    -1  
$EndComp
Text GLabel 6600 7750 0    60   Input ~ 0
GND
$Comp
L Device:C_Small C14
U 1 1 59A803C2
P 6700 6750
F 0 "C14" H 6710 6820 50  0000 L CNN
F 1 "0,1мкФ" H 6710 6670 50  0000 L CNN
F 2 "Capacitors_SMD:C_0603_HandSoldering" H 6700 6750 50  0001 C CNN
F 3 "" H 6700 6750 50  0000 C CNN
	1    6700 6750
	1    0    0    -1  
$EndComp
Text GLabel 6600 6550 0    60   Input ~ 0
3V3
Text GLabel 11150 7350 2    60   Input ~ 0
EEPROM_WP
Text GLabel 11150 7450 2    60   Input ~ 0
GND
Text GLabel 8250 7050 2    60   Input ~ 0
EEPROM_WP
$Comp
L Device:R R17
U 1 1 59A85460
P 11000 7000
F 0 "R17" V 11100 7000 50  0000 C CNN
F 1 "10k" V 11000 7000 50  0000 C CNN
F 2 "Resistors_SMD:R_0603_HandSoldering" V 10930 7000 50  0001 C CNN
F 3 "" H 11000 7000 50  0000 C CNN
	1    11000 7000
	-1   0    0    1   
$EndComp
Text GLabel 10900 6700 0    60   Input ~ 0
3V3
Text GLabel 11150 7250 2    60   Input ~ 0
CLATCH/WP
Text GLabel 9150 7350 2    60   Input ~ 0
SDA/COUT
Text GLabel 9150 7250 2    60   Input ~ 0
SCL/CCLK
Text GLabel 12500 7400 0    60   Input ~ 0
CLATCH/WP
Text GLabel 12500 7000 0    60   Input ~ 0
SDA/COUT
Text GLabel 12500 7100 0    60   Input ~ 0
SCL/CCLK
Text Notes 12725 6750 0    60   ~ 0
I2C/SPI
$Comp
L Device:R R10
U 1 1 59C8621C
P 9000 6750
F 0 "R10" H 9150 6750 50  0000 C CNN
F 1 "10k" V 9000 6750 50  0000 C CNN
F 2 "Resistors_SMD:R_0603_HandSoldering" V 8930 6750 50  0001 C CNN
F 3 "" H 9000 6750 50  0000 C CNN
	1    9000 6750
	-1   0    0    1   
$EndComp
$Comp
L Device:R R11
U 1 1 59C8680A
P 9100 6750
F 0 "R11" H 8950 6750 50  0000 C CNN
F 1 "10k" V 9100 6750 50  0000 C CNN
F 2 "Resistors_SMD:R_0603_HandSoldering" V 9030 6750 50  0001 C CNN
F 3 "" H 9100 6750 50  0000 C CNN
	1    9100 6750
	-1   0    0    1   
$EndComp
Text GLabel 8850 6400 0    60   Input ~ 0
3V3
Text GLabel 12500 6900 0    60   Input ~ 0
GND
Text GLabel 12500 7300 0    60   Input ~ 0
CDATA/WB
$Comp
L Device:CP_Small C16
U 1 1 59C8FDEC
P 9600 1300
F 0 "C16" H 9610 1370 50  0000 L CNN
F 1 "10мкФ" H 9610 1220 50  0000 L CNN
F 2 "Capacitors_Tantalum_SMD:TantalC_SizeA_EIA-3216_Reflow" H 9600 1300 50  0001 C CNN
F 3 "" H 9600 1300 50  0000 C CNN
	1    9600 1300
	0    -1   -1   0   
$EndComp
$Comp
L Device:CP_Small C17
U 1 1 59C90B70
P 9600 1900
F 0 "C17" H 9610 1970 50  0000 L CNN
F 1 "10мкФ" H 9610 1820 50  0000 L CNN
F 2 "Capacitors_Tantalum_SMD:TantalC_SizeA_EIA-3216_Reflow" H 9600 1900 50  0001 C CNN
F 3 "" H 9600 1900 50  0000 C CNN
	1    9600 1900
	0    -1   -1   0   
$EndComp
$Comp
L Device:CP_Small C18
U 1 1 59C90C89
P 9600 2500
F 0 "C18" H 9610 2570 50  0000 L CNN
F 1 "10мкФ" H 9610 2420 50  0000 L CNN
F 2 "Capacitors_Tantalum_SMD:TantalC_SizeA_EIA-3216_Reflow" H 9600 2500 50  0001 C CNN
F 3 "" H 9600 2500 50  0000 C CNN
	1    9600 2500
	0    -1   -1   0   
$EndComp
$Comp
L Device:CP_Small C19
U 1 1 59C90D9F
P 9600 3100
F 0 "C19" H 9610 3170 50  0000 L CNN
F 1 "10мкФ" H 9610 3020 50  0000 L CNN
F 2 "Capacitors_Tantalum_SMD:TantalC_SizeA_EIA-3216_Reflow" H 9600 3100 50  0001 C CNN
F 3 "" H 9600 3100 50  0000 C CNN
	1    9600 3100
	0    -1   -1   0   
$EndComp
$Comp
L RDC2-0027v3-rescue:CONN_01X03-RDC2-0027v2-rescue XP4
U 1 1 59C864E1
P 12150 1800
F 0 "XP4" H 12150 2000 50  0000 C CNN
F 1 "PLS-3" H 12150 1600 50  0000 C CNN
F 2 "Pin_Headers:Pin_Header_Straight_1x03" H 12150 1800 50  0001 C CNN
F 3 "" H 12150 1800 50  0000 C CNN
	1    12150 1800
	1    0    0    1   
$EndComp
Text GLabel 11600 1800 0    60   Input ~ 0
GND
$Comp
L RDC2-0027v3-rescue:CONN_01X03-RDC2-0027v2-rescue XP5
U 1 1 59C8A1EB
P 12150 2600
F 0 "XP5" H 12150 2800 50  0000 C CNN
F 1 "PLS-3" H 12150 2400 50  0000 C CNN
F 2 "Pin_Headers:Pin_Header_Straight_1x03" H 12150 2600 50  0001 C CNN
F 3 "" H 12150 2600 50  0000 C CNN
	1    12150 2600
	1    0    0    1   
$EndComp
$Comp
L RDC2-0027v3-rescue:CONN_01X03-RDC2-0027v2-rescue XP2
U 1 1 59C8B576
P 2450 3800
F 0 "XP2" H 2450 4000 50  0000 C CNN
F 1 "PLS-3" H 2450 3600 50  0000 C CNN
F 2 "Pin_Headers:Pin_Header_Straight_1x03" H 2450 3800 50  0001 C CNN
F 3 "" H 2450 3800 50  0000 C CNN
	1    2450 3800
	-1   0    0    -1  
$EndComp
Wire Wire Line
	6850 4800 6400 4800
Wire Wire Line
	6400 4700 6850 4700
Wire Wire Line
	6850 4600 6400 4600
Wire Wire Line
	6400 4500 6850 4500
Wire Wire Line
	6400 5100 6850 5100
Wire Wire Line
	6850 5200 6400 5200
Wire Wire Line
	6400 5300 6850 5300
Wire Wire Line
	6850 5600 6400 5600
Wire Wire Line
	8650 4900 8800 4900
Wire Wire Line
	8650 4400 8800 4400
Wire Wire Line
	8800 4400 8800 4900
Connection ~ 8800 4900
Wire Wire Line
	6400 4900 6700 4900
Wire Wire Line
	8650 6100 8800 6100
Wire Wire Line
	8800 5300 8650 5300
Wire Wire Line
	4850 5500 5050 5500
Wire Wire Line
	5050 5550 5050 5500
Connection ~ 5050 5500
Wire Wire Line
	5400 5500 5400 5550
Connection ~ 5400 5500
Wire Wire Line
	5400 5800 5400 5750
Wire Wire Line
	4850 5800 5050 5800
Wire Wire Line
	5050 5750 5050 5800
Connection ~ 5050 5800
Wire Wire Line
	8650 5200 8900 5200
Wire Wire Line
	11200 5250 11200 5200
Connection ~ 11200 5200
Wire Wire Line
	10850 5200 10850 5250
Connection ~ 10850 5200
Wire Wire Line
	10850 5500 10850 5450
Wire Wire Line
	10150 5500 10500 5500
Wire Wire Line
	11200 5450 11200 5500
Connection ~ 11200 5500
Wire Wire Line
	10150 5500 10150 5450
Connection ~ 10850 5500
Wire Wire Line
	10150 5250 10150 5200
Wire Wire Line
	10500 5250 10500 5200
Connection ~ 10500 5200
Wire Wire Line
	10500 5450 10500 5500
Connection ~ 10500 5500
Wire Wire Line
	8650 5000 8900 5000
Wire Wire Line
	8900 3800 8900 5000
Wire Wire Line
	8650 3800 8900 3800
Connection ~ 8900 5000
Wire Wire Line
	6850 4000 5750 4000
Wire Wire Line
	5450 4000 5300 4000
Wire Wire Line
	10150 4850 10150 4900
Wire Wire Line
	10150 4900 10500 4900
Wire Wire Line
	10500 4850 10500 4900
Connection ~ 10500 4900
Wire Wire Line
	10500 4600 10500 4650
Wire Wire Line
	8650 4600 10150 4600
Wire Wire Line
	10150 4650 10150 4600
Connection ~ 10150 4600
Wire Wire Line
	10150 4200 10500 4200
Wire Wire Line
	10150 4200 10150 4150
Wire Wire Line
	10500 4150 10500 4200
Connection ~ 10500 4200
Wire Wire Line
	10500 3900 10500 3950
Wire Wire Line
	8650 3900 10150 3900
Wire Wire Line
	10150 3950 10150 3900
Connection ~ 10150 3900
Wire Wire Line
	10900 4900 10900 4850
Wire Wire Line
	11250 4850 11250 4900
Connection ~ 11250 4900
Wire Wire Line
	11250 4500 11250 4650
Connection ~ 10900 4900
Wire Wire Line
	8650 4500 10900 4500
Connection ~ 10900 4500
Wire Wire Line
	10900 4650 10900 4500
Wire Wire Line
	8650 5100 11950 5100
Wire Wire Line
	11950 5100 11950 5300
Wire Wire Line
	11950 5500 12100 5500
Wire Wire Line
	12250 5300 11950 5300
Connection ~ 11950 5300
Wire Wire Line
	12300 5500 12400 5500
Wire Wire Line
	12450 5300 12800 5300
Wire Wire Line
	12800 5300 12800 5500
Wire Wire Line
	12700 5500 12800 5500
Connection ~ 12800 5500
Wire Wire Line
	6850 6100 6700 6100
Wire Wire Line
	6700 6100 6700 5000
Wire Wire Line
	3700 5000 4700 5000
Wire Wire Line
	4700 5000 4700 5050
Connection ~ 6700 5000
Wire Wire Line
	5050 5050 5050 5000
Connection ~ 5050 5000
Wire Wire Line
	5400 5050 5400 5000
Connection ~ 5400 5000
Wire Wire Line
	5400 5300 5400 5250
Wire Wire Line
	4550 5300 4700 5300
Wire Wire Line
	4700 5250 4700 5300
Connection ~ 4700 5300
Wire Wire Line
	5050 5300 5050 5250
Connection ~ 5050 5300
Connection ~ 4700 5000
Wire Wire Line
	4100 5900 4100 5800
Wire Wire Line
	3550 5900 3700 5900
Wire Wire Line
	3700 5900 3700 5600
Connection ~ 3700 5900
Wire Wire Line
	4000 5400 4100 5400
Wire Wire Line
	4100 5400 4100 5500
Wire Wire Line
	3700 5000 3700 5200
Connection ~ 4100 5400
Wire Wire Line
	4450 3400 4350 3400
Wire Wire Line
	2900 3400 3600 3400
Wire Wire Line
	3600 3450 3600 3400
Connection ~ 3600 3400
Wire Wire Line
	3800 3500 3800 3400
Connection ~ 3800 3400
Wire Wire Line
	3600 3750 3600 3800
Wire Wire Line
	2650 3800 3600 3800
Wire Wire Line
	3800 3700 3800 3800
Connection ~ 3800 3800
Connection ~ 3600 3800
Wire Wire Line
	4450 4100 4350 4100
Wire Wire Line
	2900 4100 3600 4100
Wire Wire Line
	3600 4150 3600 4100
Connection ~ 3600 4100
Wire Wire Line
	3800 4200 3800 4100
Connection ~ 3800 4100
Wire Wire Line
	3600 4450 3600 4500
Wire Wire Line
	3800 4400 3800 4500
Connection ~ 3800 4500
Wire Wire Line
	6850 4100 4750 4100
Wire Wire Line
	6850 3900 5200 3900
Wire Wire Line
	5200 3900 5200 3400
Wire Wire Line
	5200 3400 4750 3400
Wire Wire Line
	9700 1300 10000 1300
Wire Wire Line
	10650 1450 11850 1450
Wire Wire Line
	10650 1300 10650 1450
Wire Wire Line
	9700 1900 10000 1900
Wire Wire Line
	9700 2500 10000 2500
Wire Wire Line
	8650 4000 8700 4000
Wire Wire Line
	8700 4000 8700 1300
Wire Wire Line
	8700 1300 9500 1300
Wire Wire Line
	9500 1900 8800 1900
Wire Wire Line
	8800 1900 8800 4100
Wire Wire Line
	8800 4100 8650 4100
Wire Wire Line
	8650 4200 9000 4200
Wire Wire Line
	9000 4200 9000 2500
Wire Wire Line
	9000 2500 9500 2500
Wire Wire Line
	9500 3100 9100 3100
Wire Wire Line
	9100 3100 9100 4300
Wire Wire Line
	9100 4300 8650 4300
Wire Wire Line
	8650 5600 8800 5600
Connection ~ 8800 5600
Wire Wire Line
	9625 8825 9625 8925
Wire Wire Line
	9625 8925 10025 8925
Wire Wire Line
	10025 8825 10025 8925
Connection ~ 8800 5300
Connection ~ 6700 4900
Wire Wire Line
	6850 4200 6550 4200
Wire Wire Line
	6200 4300 6850 4300
Wire Wire Line
	6400 5700 6850 5700
Wire Wire Line
	6850 5800 6400 5800
Wire Wire Line
	6400 5900 6850 5900
Wire Wire Line
	6850 6000 6400 6000
Wire Wire Line
	7500 7750 7500 7650
Wire Wire Line
	6600 7750 6700 7750
Wire Wire Line
	6800 6950 6700 6950
Connection ~ 6700 7750
Wire Wire Line
	6700 7050 6800 7050
Connection ~ 6700 7050
Wire Wire Line
	6700 7150 6800 7150
Connection ~ 6700 7150
Wire Wire Line
	6600 6550 6700 6550
Wire Wire Line
	7500 6550 7500 6650
Wire Wire Line
	6700 6650 6700 6550
Connection ~ 6700 6550
Connection ~ 6700 6950
Wire Wire Line
	8200 7050 8250 7050
Wire Wire Line
	10900 6700 11000 6700
Wire Wire Line
	11000 6700 11000 6850
Wire Wire Line
	11000 7150 11000 7250
Connection ~ 11000 7250
Wire Wire Line
	12700 7000 12500 7000
Wire Wire Line
	12500 7100 12700 7100
Wire Wire Line
	12700 7200 12500 7200
Wire Wire Line
	6700 6850 6700 6950
Wire Wire Line
	9000 6900 9000 7250
Connection ~ 9000 7250
Wire Wire Line
	9100 6900 9100 7350
Connection ~ 9100 7350
Wire Wire Line
	8850 6400 9000 6400
Wire Wire Line
	9000 6400 9000 6600
Wire Wire Line
	9100 6400 9100 6600
Connection ~ 9000 6400
Wire Wire Line
	12500 7300 12700 7300
Wire Wire Line
	6850 3800 6700 3800
Wire Wire Line
	11850 1450 11850 1700
Wire Wire Line
	11850 1700 11950 1700
Wire Wire Line
	11600 1800 11950 1800
Wire Wire Line
	11600 2600 11950 2600
Wire Wire Line
	9700 3100 10025 3100
Wire Wire Line
	11650 3100 11650 2700
Wire Wire Line
	11650 2700 11950 2700
Wire Wire Line
	3600 4500 3800 4500
Wire Wire Line
	2900 4100 2900 3900
Wire Wire Line
	2900 3900 2650 3900
Wire Wire Line
	2650 3700 2900 3700
Wire Wire Line
	2900 3700 2900 3400
$Comp
L Device:R R5
U 1 1 59A6B6CD
P 4600 4100
F 0 "R5" V 4525 4050 50  0000 C CNN
F 1 "8k06" V 4600 4100 50  0000 C CNN
F 2 "Resistors_SMD:R_0603_HandSoldering" V 4530 4100 50  0001 C CNN
F 3 "" H 4600 4100 50  0000 C CNN
	1    4600 4100
	0    1    1    0   
$EndComp
$Comp
L Device:R R4
U 1 1 59A65DA9
P 4600 3400
F 0 "R4" V 4525 3350 50  0000 C CNN
F 1 "8k06" V 4600 3400 50  0000 C CNN
F 2 "Resistors_SMD:R_0603_HandSoldering" V 4530 3400 50  0001 C CNN
F 3 "" H 4600 3400 50  0000 C CNN
	1    4600 3400
	0    1    1    0   
$EndComp
$Comp
L RDC2-0027v3-rescue:LP2985LV-RDC2-0027v2-rescue U1
U 1 1 59C9044B
P 3200 1150
F 0 "U1" H 3400 700 50  0000 C CNN
F 1 "LP2985LV" H 3200 1600 50  0000 C CNN
F 2 "TO_SOT_Packages_SMD:SOT-23-5" H 3200 1150 50  0001 C CNN
F 3 "" H 3200 1150 50  0000 C CNN
	1    3200 1150
	1    0    0    -1  
$EndComp
$Comp
L Device:CP_Small C5
U 1 1 59C926AE
P 4100 1175
F 0 "C5" H 4110 1245 50  0000 L CNN
F 1 "100мкФ" H 4110 1095 50  0000 L CNN
F 2 "Capacitor_Tantalum_SMD:CP_EIA-3528-21_Kemet-B_Pad1.50x2.35mm_HandSolder" H 4100 1175 50  0001 C CNN
F 3 "46079" H 4100 1175 50  0001 C CNN
	1    4100 1175
	1    0    0    -1  
$EndComp
Wire Wire Line
	3200 1850 3200 2050
Wire Wire Line
	4000 850  4100 850 
Wire Wire Line
	4100 850  4100 1075
Wire Wire Line
	2400 1050 2125 1050
Wire Wire Line
	2125 1050 2125 850 
Connection ~ 2125 850 
$Comp
L Device:C_Small C2
U 1 1 59C93F61
P 2325 1600
F 0 "C2" H 2335 1670 50  0000 L CNN
F 1 "0,01мкФ" H 2335 1520 50  0000 L CNN
F 2 "Capacitors_SMD:C_0603_HandSoldering" H 2325 1600 50  0001 C CNN
F 3 "" H 2325 1600 50  0000 C CNN
	1    2325 1600
	1    0    0    -1  
$EndComp
Wire Wire Line
	2325 1500 2325 1350
Wire Wire Line
	2325 1350 2400 1350
Wire Wire Line
	2325 2050 2325 1700
Connection ~ 4100 850 
$Comp
L Device:R R13
U 1 1 59C96B23
P 10175 1500
F 0 "R13" V 10275 1550 50  0000 C CNN
F 1 "49k9" V 10175 1500 50  0000 C CNN
F 2 "Resistors_SMD:R_0603_HandSoldering" V 10105 1500 50  0001 C CNN
F 3 "" H 10175 1500 50  0000 C CNN
	1    10175 1500
	1    0    0    -1  
$EndComp
$Comp
L Device:C_Small C21
U 1 1 59C9725A
P 10000 1500
F 0 "C21" H 10010 1570 50  0000 L CNN
F 1 "100пФ" H 10010 1420 50  0000 L CNN
F 2 "Capacitors_SMD:C_0603_HandSoldering" H 10000 1500 50  0001 C CNN
F 3 "" H 10000 1500 50  0000 C CNN
	1    10000 1500
	1    0    0    -1  
$EndComp
Wire Wire Line
	10000 1400 10000 1300
Connection ~ 10000 1300
Wire Wire Line
	10175 1350 10175 1300
Connection ~ 10175 1300
Wire Wire Line
	10000 1600 10000 1700
Wire Wire Line
	10000 1700 10175 1700
Wire Wire Line
	10175 1700 10175 1650
Text GLabel 10500 1700 2    60   Input ~ 0
GND
Connection ~ 10175 1700
$Comp
L Device:C_Small C22
U 1 1 59C9872D
P 10000 2100
F 0 "C22" H 10010 2170 50  0000 L CNN
F 1 "100пФ" H 10010 2020 50  0000 L CNN
F 2 "Capacitors_SMD:C_0603_HandSoldering" H 10000 2100 50  0001 C CNN
F 3 "" H 10000 2100 50  0000 C CNN
	1    10000 2100
	1    0    0    -1  
$EndComp
$Comp
L Device:R R14
U 1 1 59C98812
P 10175 2150
F 0 "R14" V 10275 2200 50  0000 C CNN
F 1 "49k9" V 10175 2150 50  0000 C CNN
F 2 "Resistors_SMD:R_0603_HandSoldering" V 10105 2150 50  0001 C CNN
F 3 "" H 10175 2150 50  0000 C CNN
	1    10175 2150
	1    0    0    -1  
$EndComp
Wire Wire Line
	10000 2000 10000 1900
Connection ~ 10000 1900
Wire Wire Line
	10175 2000 10175 1900
Connection ~ 10175 1900
Wire Wire Line
	10000 2200 10000 2350
Wire Wire Line
	10000 2350 10175 2350
Wire Wire Line
	10175 2350 10175 2300
Text GLabel 10425 2350 2    60   Input ~ 0
GND
Connection ~ 10175 2350
$Comp
L Device:C_Small C23
U 1 1 59C997FC
P 10000 2700
F 0 "C23" H 10010 2770 50  0000 L CNN
F 1 "100пФ" H 10010 2620 50  0000 L CNN
F 2 "Capacitors_SMD:C_0603_HandSoldering" H 10000 2700 50  0001 C CNN
F 3 "" H 10000 2700 50  0000 C CNN
	1    10000 2700
	1    0    0    -1  
$EndComp
$Comp
L Device:R R15
U 1 1 59C998EB
P 10175 2750
F 0 "R15" V 10275 2800 50  0000 C CNN
F 1 "49k9" V 10175 2750 50  0000 C CNN
F 2 "Resistors_SMD:R_0603_HandSoldering" V 10105 2750 50  0001 C CNN
F 3 "" H 10175 2750 50  0000 C CNN
	1    10175 2750
	1    0    0    -1  
$EndComp
Text GLabel 10375 2950 2    60   Input ~ 0
GND
Wire Wire Line
	10000 2600 10000 2500
Connection ~ 10000 2500
Wire Wire Line
	10175 2600 10175 2500
Connection ~ 10175 2500
Wire Wire Line
	10000 2800 10000 2950
Wire Wire Line
	10000 2950 10175 2950
Wire Wire Line
	10175 2900 10175 2950
Connection ~ 10175 2950
$Comp
L Device:C_Small C24
U 1 1 59C9A8D0
P 10025 3325
F 0 "C24" H 10035 3395 50  0000 L CNN
F 1 "100пФ" H 10035 3245 50  0000 L CNN
F 2 "Capacitors_SMD:C_0603_HandSoldering" H 10025 3325 50  0001 C CNN
F 3 "" H 10025 3325 50  0000 C CNN
	1    10025 3325
	1    0    0    -1  
$EndComp
$Comp
L Device:R R16
U 1 1 59C9A9B7
P 10200 3350
F 0 "R16" V 10300 3400 50  0000 C CNN
F 1 "49k9" V 10200 3350 50  0000 C CNN
F 2 "Resistors_SMD:R_0603_HandSoldering" V 10130 3350 50  0001 C CNN
F 3 "" H 10200 3350 50  0000 C CNN
	1    10200 3350
	1    0    0    -1  
$EndComp
Text GLabel 10375 3575 2    60   Input ~ 0
GND
Wire Wire Line
	10025 3225 10025 3100
Connection ~ 10025 3100
Wire Wire Line
	10200 3200 10200 3100
Connection ~ 10200 3100
Wire Wire Line
	10025 3425 10025 3575
Wire Wire Line
	10025 3575 10200 3575
Wire Wire Line
	10200 3500 10200 3575
Connection ~ 10200 3575
Text GLabel 2450 6925 2    60   Input ~ 0
MP11
Text GLabel 2450 6825 2    60   Input ~ 0
MP10
Text GLabel 6200 2950 1    60   Input ~ 0
3V3
Wire Wire Line
	6200 2950 6200 4300
$Comp
L Device:CP_Small C1
U 1 1 59CB2176
P 1900 1150
F 0 "C1" H 1910 1220 50  0000 L CNN
F 1 "100мкФ" H 1910 1070 50  0000 L CNN
F 2 "Capacitor_Tantalum_SMD:CP_EIA-3528-21_Kemet-B_Pad1.50x2.35mm_HandSolder" H 1900 1150 50  0001 C CNN
F 3 "46079" H 1900 1150 50  0001 C CNN
	1    1900 1150
	1    0    0    -1  
$EndComp
Wire Wire Line
	8800 4900 8800 5300
Wire Wire Line
	5050 5500 5400 5500
Wire Wire Line
	5400 5500 6850 5500
Wire Wire Line
	5050 5800 5400 5800
Wire Wire Line
	11200 5200 11550 5200
Wire Wire Line
	10850 5200 11200 5200
Wire Wire Line
	11200 5500 11550 5500
Wire Wire Line
	10850 5500 11200 5500
Wire Wire Line
	10150 5200 10500 5200
Wire Wire Line
	10500 5200 10850 5200
Wire Wire Line
	10500 5500 10850 5500
Wire Wire Line
	8900 5000 8900 5200
Wire Wire Line
	10500 4900 10900 4900
Wire Wire Line
	10150 4600 10500 4600
Wire Wire Line
	10500 4200 10800 4200
Wire Wire Line
	10150 3900 10500 3900
Wire Wire Line
	11250 4900 11550 4900
Wire Wire Line
	10900 4900 11250 4900
Wire Wire Line
	10900 4500 11250 4500
Wire Wire Line
	11950 5300 11950 5500
Wire Wire Line
	12800 5500 12900 5500
Wire Wire Line
	6700 5000 6850 5000
Wire Wire Line
	5050 5000 5400 5000
Wire Wire Line
	5400 5000 6700 5000
Wire Wire Line
	4700 5300 5050 5300
Wire Wire Line
	5050 5300 5400 5300
Wire Wire Line
	4700 5000 5050 5000
Wire Wire Line
	3700 5900 4100 5900
Wire Wire Line
	4100 5400 6850 5400
Wire Wire Line
	3600 3400 3800 3400
Wire Wire Line
	3800 3400 4150 3400
Wire Wire Line
	3800 3800 3950 3800
Wire Wire Line
	3600 3800 3800 3800
Wire Wire Line
	3600 4100 3800 4100
Wire Wire Line
	3800 4100 4150 4100
Wire Wire Line
	3800 4500 3950 4500
Wire Wire Line
	8800 5600 8800 6100
Wire Wire Line
	8800 5300 8800 5600
Wire Wire Line
	6700 4900 6850 4900
Wire Wire Line
	6700 7750 7500 7750
Wire Wire Line
	6700 7050 6700 7150
Wire Wire Line
	6700 7150 6700 7750
Wire Wire Line
	6700 6550 7500 6550
Wire Wire Line
	6700 6950 6700 7050
Wire Wire Line
	11000 7250 11150 7250
Wire Wire Line
	9000 7250 9150 7250
Wire Wire Line
	9100 7350 9150 7350
Wire Wire Line
	9000 6400 9100 6400
Wire Wire Line
	2125 850  2400 850 
Wire Wire Line
	1900 2050 2325 2050
Wire Wire Line
	1900 850  1900 1050
Wire Wire Line
	1900 850  2125 850 
Wire Wire Line
	10000 1300 10175 1300
Wire Wire Line
	10175 1300 10650 1300
Wire Wire Line
	10175 1700 10500 1700
Wire Wire Line
	10000 1900 10175 1900
Wire Wire Line
	10175 1900 11950 1900
Wire Wire Line
	10175 2350 10425 2350
Wire Wire Line
	10000 2500 10175 2500
Wire Wire Line
	10175 2500 11950 2500
Wire Wire Line
	10175 2950 10375 2950
Wire Wire Line
	10025 3100 10200 3100
Wire Wire Line
	10200 3100 11650 3100
Wire Wire Line
	10200 3575 10375 3575
Wire Wire Line
	8200 7250 9000 7250
Wire Wire Line
	8200 7350 9100 7350
Wire Wire Line
	2350 6225 2450 6225
Wire Wire Line
	2350 6325 2450 6325
Wire Wire Line
	2350 6425 2450 6425
Wire Wire Line
	2350 6525 2450 6525
Wire Wire Line
	2350 6625 2450 6625
Wire Wire Line
	2350 6725 2450 6725
Wire Wire Line
	2350 6825 2450 6825
Wire Wire Line
	2350 6925 2450 6925
Wire Wire Line
	2350 7025 2450 7025
$Comp
L Connector:Conn_01x04_Male J1
U 1 1 5CF39075
P 12900 7000
F 0 "J1" H 12872 6928 50  0000 R CNN
F 1 "Conn_01x04_Male" H 12872 6883 50  0001 R CNN
F 2 "Connector_PinHeader_2.54mm:PinHeader_1x04_P2.54mm_Vertical" H 12900 7000 50  0001 C CNN
F 3 "~" H 12900 7000 50  0001 C CNN
	1    12900 7000
	-1   0    0    -1  
$EndComp
Wire Wire Line
	12500 6900 12700 6900
Text GLabel 12500 7200 0    60   Input ~ 0
3V3
Wire Wire Line
	12500 7400 12700 7400
$Comp
L Connector:Conn_01x07_Male J6
U 1 1 5D092E20
P 12900 8275
F 0 "J6" H 12872 8253 50  0000 R CNN
F 1 "Conn_01x07_Male" H 12872 8208 50  0001 R CNN
F 2 "Connector_PinHeader_2.54mm:PinHeader_1x07_P2.54mm_Vertical" H 12900 8275 50  0001 C CNN
F 3 "~" H 12900 8275 50  0001 C CNN
	1    12900 8275
	-1   0    0    -1  
$EndComp
Text GLabel 12575 7975 0    60   Input ~ 0
GND
Wire Wire Line
	12575 7975 12700 7975
Text GLabel 12575 8075 0    60   Input ~ 0
EXT_MCLK
Wire Wire Line
	12575 8075 12700 8075
Wire Wire Line
	12575 8175 12700 8175
Wire Wire Line
	12575 8275 12700 8275
Wire Wire Line
	12575 8375 12700 8375
Text GLabel 12575 8475 0    60   Input ~ 0
3V3
Wire Wire Line
	12700 8475 12575 8475
Text GLabel 12575 8575 0    60   Input ~ 0
RST
Wire Wire Line
	12575 8575 12700 8575
$Comp
L Connector:Conn_01x09_Male J2
U 1 1 5D1DAA4D
P 2150 6625
F 0 "J2" H 2258 7114 50  0000 C CNN
F 1 "Conn_01x09_Male" H 2258 7115 50  0001 C CNN
F 2 "Connector_PinHeader_2.54mm:PinHeader_1x09_P2.54mm_Vertical" H 2150 6625 50  0001 C CNN
F 3 "~" H 2150 6625 50  0001 C CNN
	1    2150 6625
	1    0    0    -1  
$EndComp
Wire Wire Line
	8650 5700 8875 5700
Wire Wire Line
	8650 5800 8875 5800
Wire Wire Line
	8650 5900 8875 5900
Wire Wire Line
	8650 6000 8875 6000
Connection ~ 8900 5200
Connection ~ 10150 5200
$Comp
L Device:R R12
U 1 1 59A5E09C
P 9325 8225
F 0 "R12" V 9275 8375 50  0000 C CNN
F 1 "100R" V 9325 8225 50  0000 C CNN
F 2 "Resistors_SMD:R_0603_HandSoldering" V 9255 8225 50  0001 C CNN
F 3 "" H 9325 8225 50  0000 C CNN
	1    9325 8225
	0    1    1    0   
$EndComp
Wire Wire Line
	9625 8225 9625 8375
Connection ~ 9625 8375
$Comp
L Device:Crystal BQ1
U 1 1 59A5D697
P 9825 8375
F 0 "BQ1" H 9825 8525 50  0000 C CNN
F 1 "12M288" H 9825 8225 50  0000 C CNN
F 2 "Crystals:Crystal_HC49-U_Vertical" H 9825 8375 50  0001 C CNN
F 3 "" H 9825 8375 50  0000 C CNN
	1    9825 8375
	1    0    0    -1  
$EndComp
Wire Wire Line
	9475 8225 9625 8225
$Comp
L Connector:Conn_01x02_Male J5
U 1 1 5D1DE345
P 9100 5500
F 0 "J5" H 9072 5382 50  0000 R CNN
F 1 "Conn_01x02_Male" H 9072 5473 50  0001 R CNN
F 2 "Connector_PinHeader_2.54mm:PinHeader_1x02_P2.54mm_Vertical" H 9100 5500 50  0001 C CNN
F 3 "~" H 9100 5500 50  0001 C CNN
	1    9100 5500
	-1   0    0    1   
$EndComp
Wire Wire Line
	9625 8375 9625 8625
Wire Wire Line
	10025 8375 10025 8625
Wire Wire Line
	8900 5200 10150 5200
Wire Wire Line
	9675 8375 9625 8375
Connection ~ 10025 8375
Wire Wire Line
	9975 8375 10025 8375
Wire Wire Line
	10025 8125 10025 8375
Text GLabel 8875 5700 2    60   Input ~ 0
MP2
Text GLabel 8875 5800 2    60   Input ~ 0
MP3
Wire Wire Line
	8800 6100 8875 6100
Connection ~ 8800 6100
Wire Wire Line
	8650 5400 8850 5400
Wire Wire Line
	8650 5500 8900 5500
Wire Wire Line
	9175 8125 10025 8125
$Comp
L Connector:Conn_01x03_Male J7
U 1 1 5D3AAA72
P 8975 8225
F 0 "J7" H 8947 8157 50  0000 R CNN
F 1 "Conn_01x03_Male" H 8947 8248 50  0000 R CNN
F 2 "Connector_PinHeader_2.54mm:PinHeader_1x03_P2.54mm_Vertical" H 8975 8225 50  0001 C CNN
F 3 "~" H 8975 8225 50  0001 C CNN
	1    8975 8225
	1    0    0    1   
$EndComp
Wire Wire Line
	2325 2050 3100 2050
Connection ~ 2325 2050
Connection ~ 3200 2050
Wire Wire Line
	3200 2050 3200 2225
Wire Wire Line
	4100 1275 4100 2050
Wire Wire Line
	4100 2050 3200 2050
Wire Wire Line
	1900 1250 1900 2050
$Comp
L Connector:Conn_01x04_Male J4
U 1 1 5D4D526C
P 3200 2425
F 0 "J4" V 3354 2569 50  0000 L CNN
F 1 "Conn_01x04_Male" V 3263 2569 50  0000 L CNN
F 2 "Connector_PinHeader_2.54mm:PinHeader_1x04_P2.54mm_Vertical" H 3200 2425 50  0001 C CNN
F 3 "~" H 3200 2425 50  0001 C CNN
	1    3200 2425
	0    1    -1   0   
$EndComp
Wire Wire Line
	3100 2225 3100 2050
Connection ~ 3100 2050
Wire Wire Line
	3100 2050 3200 2050
Wire Wire Line
	1900 850  1675 850 
Wire Wire Line
	1675 850  1675 2175
Wire Wire Line
	1675 2175 3000 2175
Wire Wire Line
	3000 2175 3000 2225
Connection ~ 1900 850 
Wire Wire Line
	4400 850  4400 2175
Wire Wire Line
	4400 2175 3300 2175
Wire Wire Line
	3300 2175 3300 2225
Wire Wire Line
	4100 850  4400 850 
Wire Wire Line
	9175 8325 9400 8325
Wire Wire Line
	9400 8325 9400 8925
Wire Wire Line
	9400 8925 9625 8925
Connection ~ 9625 8925
$Comp
L Connector:Conn_01x03_Male J8
U 1 1 5D59233D
P 10700 7350
F 0 "J8" H 10673 7328 50  0000 R CNN
F 1 "Conn_01x03_Male" H 10672 7373 50  0001 R CNN
F 2 "Connector_PinHeader_2.54mm:PinHeader_1x03_P2.54mm_Vertical" H 10700 7350 50  0001 C CNN
F 3 "~" H 10700 7350 50  0001 C CNN
	1    10700 7350
	1    0    0    1   
$EndComp
Wire Wire Line
	10900 7250 11000 7250
Wire Wire Line
	10900 7350 11150 7350
Wire Wire Line
	10900 7450 11150 7450
$Comp
L Connector:Conn_01x02_Male J3
U 1 1 5D77EF6A
P 12900 7400
F 0 "J3" H 12775 7325 50  0000 L CNN
F 1 "Conn_01x02_Male" V 13053 7444 50  0001 L CNN
F 2 "Connector_PinHeader_2.54mm:PinHeader_1x02_P2.54mm_Vertical" H 12900 7400 50  0001 C CNN
F 3 "~" H 12900 7400 50  0001 C CNN
	1    12900 7400
	-1   0    0    1   
$EndComp
Text GLabel 9750 4700 2    60   Input ~ 0
3V3
Text GLabel 9750 4900 2    60   Input ~ 0
GND
$Comp
L Device:R R8
U 1 1 5E01DAA6
P 9600 4700
F 0 "R8" V 9650 4850 50  0000 C CNN
F 1 "10k" V 9600 4700 50  0000 C CNN
F 2 "Resistor_SMD:R_0603_1608Metric_Pad1.05x0.95mm_HandSolder" V 9530 4700 50  0001 C CNN
F 3 "" H 9600 4700 50  0000 C CNN
	1    9600 4700
	0    -1   -1   0   
$EndComp
$Comp
L Device:R R19
U 1 1 5E01E7E6
P 9600 4900
F 0 "R19" V 9625 5050 50  0000 C CNN
F 1 "N.A" V 9600 4900 50  0000 C CNN
F 2 "Resistor_SMD:R_0603_1608Metric_Pad1.05x0.95mm_HandSolder" V 9530 4900 50  0001 C CNN
F 3 "" H 9600 4900 50  0000 C CNN
	1    9600 4900
	0    -1   -1   0   
$EndComp
Wire Wire Line
	8650 4700 9400 4700
Wire Wire Line
	9450 4900 9400 4900
Wire Wire Line
	9400 4900 9400 4700
Connection ~ 9400 4700
Wire Wire Line
	9400 4700 9450 4700
$Comp
L Device:R R20
U 1 1 5E078A28
P 9600 5025
F 0 "R20" V 9650 5175 50  0000 C CNN
F 1 "0" V 9600 5025 50  0000 C CNN
F 2 "Resistor_SMD:R_0603_1608Metric_Pad1.05x0.95mm_HandSolder" V 9530 5025 50  0001 C CNN
F 3 "" H 9600 5025 50  0000 C CNN
	1    9600 5025
	0    -1   -1   0   
$EndComp
$Comp
L Device:R R9
U 1 1 5E078FDB
P 9600 4800
F 0 "R9" V 9650 4950 50  0000 C CNN
F 1 "N.A" V 9600 4800 50  0000 C CNN
F 2 "Resistor_SMD:R_0603_1608Metric_Pad1.05x0.95mm_HandSolder" V 9530 4800 50  0001 C CNN
F 3 "" H 9600 4800 50  0000 C CNN
	1    9600 4800
	0    -1   -1   0   
$EndComp
Text GLabel 9750 4800 2    60   Input ~ 0
3V3
Text GLabel 9750 5025 2    60   Input ~ 0
GND
Wire Wire Line
	9450 4800 9300 4800
Wire Wire Line
	9300 4800 9300 5025
Wire Wire Line
	9300 5025 9450 5025
Wire Wire Line
	8650 4800 9300 4800
Connection ~ 9300 4800
$Comp
L RDC2-0027v3-rescue:ADM6316-PowerResetSupervisor D1
U 1 1 5E117E49
P 7600 2275
F 0 "D1" H 7600 2664 60  0000 C CNN
F 1 "ADM6316" H 7600 2558 60  0000 C CNN
F 2 "Package_TO_SOT_SMD:SOT-23-5_HandSoldering" H 7600 2275 60  0001 C CNN
F 3 "" H 7600 2275 60  0001 C CNN
	1    7600 2275
	1    0    0    -1  
$EndComp
Text GLabel 8100 1975 1    60   Input ~ 0
3V3
Wire Wire Line
	7900 2175 8100 2175
Wire Wire Line
	8100 2175 8100 1975
Wire Wire Line
	7300 2375 7250 2375
Wire Wire Line
	7250 2375 7250 2700
Wire Wire Line
	7900 2375 7925 2375
Wire Wire Line
	7925 2375 7925 2700
Text GLabel 7225 2275 0    60   Input ~ 0
GND
Wire Wire Line
	7225 2275 7300 2275
Wire Wire Line
	6550 2175 7300 2175
Wire Wire Line
	6550 2175 6550 4200
Wire Wire Line
	7650 2700 7925 2700
Text GLabel 7125 2700 0    60   Input ~ 0
RST
Wire Wire Line
	7125 2700 7250 2700
$Comp
L Connector_Generic:Conn_01x01 J9
U 1 1 5E27D61A
P 7450 2700
F 0 "J9" H 7368 2567 50  0000 C CNN
F 1 "Conn_01x01" H 7368 2566 50  0001 C CNN
F 2 "Connector_PinSocket_2.54mm:PinSocket_1x01_P2.54mm_Vertical" H 7450 2700 50  0001 C CNN
F 3 "~" H 7450 2700 50  0001 C CNN
	1    7450 2700
	-1   0    0    1   
$EndComp
Text GLabel 9450 9125 0    60   Input ~ 0
GND_1
Wire Wire Line
	9625 8925 9625 9125
Wire Wire Line
	9625 9125 9450 9125
Text GLabel 3000 1850 0    60   Input ~ 0
GND_1
Wire Wire Line
	3100 2050 3100 1850
Wire Wire Line
	3100 1850 3000 1850
Text GLabel 9425 5325 2    60   Input ~ 0
EXT_MCLK
Wire Wire Line
	8850 5400 8850 5325
Wire Wire Line
	8850 5325 9425 5325
Connection ~ 8850 5400
Wire Wire Line
	8850 5400 8900 5400
$Comp
L Connector:Conn_01x02_Male J10
U 1 1 5E37CA95
P 5875 4175
F 0 "J10" H 5750 4100 50  0000 L CNN
F 1 "Conn_01x02_Male" V 6028 4219 50  0001 L CNN
F 2 "Connector_PinHeader_2.54mm:PinHeader_1x02_P2.54mm_Vertical" H 5875 4175 50  0001 C CNN
F 3 "~" H 5875 4175 50  0001 C CNN
	1    5875 4175
	0    1    1    0   
$EndComp
Wire Wire Line
	6700 3800 6700 4900
Wire Wire Line
	5875 4400 5875 4375
Text GLabel 5775 4475 3    60   Input ~ 0
GND
Wire Wire Line
	5775 4375 5775 4475
Wire Wire Line
	5875 4400 6850 4400
$Comp
L Connector:Conn_01x02_Male J11
U 1 1 5E48DB5F
P 12825 9175
F 0 "J11" H 12700 9100 50  0000 L CNN
F 1 "Conn_01x02_Male" V 12978 9219 50  0001 L CNN
F 2 "Connector_PinHeader_2.54mm:PinHeader_1x02_P2.54mm_Vertical" H 12825 9175 50  0001 C CNN
F 3 "~" H 12825 9175 50  0001 C CNN
	1    12825 9175
	-1   0    0    1   
$EndComp
Text GLabel 12625 9075 0    60   Input ~ 0
3V3
Text GLabel 12625 9175 0    60   Input ~ 0
GND
$EndSCHEMATC
